import DashboardCard from "../DashboardCard";
import { toggleCompanyStatus, createCompanyUser } from "../../services/adminCompanies";
import { Power } from "lucide-react";
import { useState, useEffect } from "react";

export default function CompanyTable({ companies, loading }) {

  const handleToggle = async (companyId) => {
    try {
      const res = await toggleCompanyStatus(companyId);

      setLocalCompanies(prev =>
        prev.map(c =>
          c.id === companyId
            ? { ...c, is_active: res.data.is_active }
            : c
        )
      );
    } catch (err) {
      console.error("Toggle failed", err);
      alert("Failed to update company status");
    }
  };

  const [localCompanies, setLocalCompanies] = useState(companies);

  useEffect(() => {
    setLocalCompanies(companies);
  }, [companies]);

  const [userModalCompany, setUserModalCompany] = useState(null);
  const [newUserEmail, setNewUserEmail] = useState("");
  const [generatedCredentials, setGeneratedCredentials] = useState(null);

  const openUserModal = (companyId) => {
    setUserModalCompany(companyId);
  };


  // Escape Button 

  useEffect(() => {
  const handleEsc = (e) => {
    if (e.key === "Escape") {
      setUserModalCompany(null);
    }
  };

  window.addEventListener("keydown", handleEsc);
  return () => window.removeEventListener("keydown", handleEsc);
}, []);




  const handleCreateUser = async () => {
    try {
      const res = await createCompanyUser(userModalCompany, {
        email: newUserEmail,
      });

      setGeneratedCredentials({
        username: res.data.username,
        password: res.data.password,
      });

      setUserModalCompany(null);
      setNewUserEmail("");
    } catch (err) {
      console.error(err);
      alert("Failed to create user");
    }
  };

  return (
    <>
      <DashboardCard>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-900/60 text-slate-400">
              <tr>
                <th className="px-6 py-4 text-left">Company</th>
                <th className="px-6 py-4 text-left">Email</th>
                <th className="px-6 py-4 text-left">Credit</th>
                <th className="px-6 py-4 text-left">Currency</th>
                <th className="px-6 py-4 text-left">Status</th>
                <th className="px-6 py-4 text-left">Created</th>
                <th className="px-6 py-4 text-left">Actions</th>
                <th className="px-6 py-4 text-left">Add Clients</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-700/50">
              {loading ? (
                <tr>
                  <td colSpan="7" className="px-6 py-8 text-center text-slate-400">
                    Loading companies…
                  </td>
                </tr>
              ) : localCompanies.length === 0 ? (
                <tr>
                  <td colSpan="7" className="px-6 py-8 text-center text-slate-500">
                    No companies found
                  </td>
                </tr>
              ) : (
                localCompanies.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-700/20">
                    <td className="px-6 py-4 text-white font-medium">
                      {c.name}
                    </td>

                    <td className="px-6 py-4 text-slate-300">
                      {c.email}
                    </td>

                    <td className="px-6 py-4 text-emerald-400 font-mono">
                      {c.credit_balance}
                    </td>

                    <td className="px-6 py-4 text-slate-300">
                      {c.currency}
                    </td>

                    <td className="px-6 py-4">
                      <span
                        className={`px-2 py-1 rounded text-xs font-semibold ${c.is_active
                          ? "bg-emerald-500/10 text-emerald-400"
                          : "bg-rose-500/10 text-rose-400"
                          }`}
                      >
                        {c.is_active ? "Active" : "Disabled"}
                      </span>
                    </td>

                    <td className="px-6 py-4 text-xs text-slate-400">
                      {new Date(c.created_at).toLocaleDateString()}
                    </td>

                    {/* Toggle Button */}
                    <td className="px-6 py-4 text-right">
                      <button
                        onClick={() => handleToggle(c.id)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${c.is_active
                          ? "bg-rose-500/10 text-rose-400 hover:bg-rose-500/20"
                          : "bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20"
                          }`}
                      >
                        <Power size={14} />
                        {c.is_active ? "Deactivate" : "Activate"}
                      </button>
                    </td>
                    <td className="px-6 py-4 ">
                      <button onClick={() => openUserModal(c.id)}
                        className="px-3 py-1 text-xs bg-sky-500/10 text-sky-400 rounded-lg"
                      >
                        Add User
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>

        </div>
      </DashboardCard>
      {userModalCompany && (
  <div
    className="fixed inset-0 bg-black/60 flex items-center justify-center z-50"
    onClick={() => setUserModalCompany(null)}   // click outside closes
  >
    <div
      className="bg-slate-900 p-6 rounded-xl w-96 border border-slate-700 relative"
      onClick={(e) => e.stopPropagation()}      // prevent close when clicking inside
    >
      {/* Close Button */}
      <button
        onClick={() => setUserModalCompany(null)}
        className="absolute top-3 right-3 text-slate-400 hover:text-white text-lg"
      >
        ✕
      </button>

      <h3 className="text-white font-bold mb-4">
        Add Client User
      </h3>

      <input
        placeholder="Email"
        value={newUserEmail}
        onChange={(e) => setNewUserEmail(e.target.value)}
        className="w-full mb-4 bg-slate-800 px-3 py-2 rounded text-white"
      />

      <button
        onClick={handleCreateUser}
        className="w-full bg-sky-600 hover:bg-sky-500 py-2 rounded text-white font-semibold"
      >
        Create User
      </button>
    </div>
  </div>
)}
      {generatedCredentials && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="bg-slate-900 p-6 rounded-xl w-96 border border-slate-700">
            <h3 className="text-white font-bold mb-4">
              User Created Successfully
            </h3>

            <div className="text-sm space-y-2">
              <div>
                Username: <span className="text-emerald-400 font-mono">{generatedCredentials.username}</span>
              </div>
              <div>
                Password: <span className="text-rose-400 font-mono">{generatedCredentials.password}</span>
              </div>
            </div>

            <button
              onClick={() => setGeneratedCredentials(null)}
              className="mt-4 w-full bg-sky-600 py-2 rounded text-white"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
}
